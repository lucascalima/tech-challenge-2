import numpy as np

arr = np.array([1])
np.nditer([arr, None])
